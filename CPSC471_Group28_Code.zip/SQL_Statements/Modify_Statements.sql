 UPDATE User_ SET Password_=? WHERE Email=?;

 UPDATE User_ SET Password_=? WHERE Email=?

 UPDATE tasks SET isDone = 1 WHERE ListID = ? AND Task = ?

 UPDATE Student_Course SET Grade=? WHERE SEmail=? AND CName=? AND CNumber=?